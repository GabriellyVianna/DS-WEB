function trocarfundoazul(){
    document.body.style.backgroundColor="#191970"
    document.getElementById("titulo").innerText="Boa noite"
}

function trocarfundoverde(){
    document.body.style.backgroundColor="#556B2F"
    document.getElementById("titulo").innerText="Boa tarde"
}

function trocarfundovermelho(){
    document.body.style.backgroundColor="#8B0000"
    document.getElementById("titulo").innerText="Boa madrugada"
}