let a =prompt("Digite seu nome:");
let b =prompt("Digite seu sobrenome:");
alert(a + b);
