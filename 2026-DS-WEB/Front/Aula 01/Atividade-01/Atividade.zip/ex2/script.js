let a =Number (prompt("Digite um número para calcular a adição:"));
let b =Number (prompt("Digite outro número:"));
alert(a + b);

let c =Number (prompt("Digite um número para calcular a subtração:"));
let d =Number (prompt("Digite outro número:"));
alert(c - d);

let e =Number (prompt("Digite um número para calcular a multiplicação:"));
let f =Number (prompt("Digite outro número:"));
alert(e * f);

let g =Number (prompt("Digite um número para calcular a divisão:"));
let h =Number (prompt("Digite outro número:"));
alert(g / h);

let i =Number (prompt("Digite um número para calcular o resto:"));
let j =Number (prompt("Digite outro número:"));
alert(i % j);

let k =Number (prompt("Digite um número para calcular a potencia:"));
let l =Number (prompt("Digite outro número:"));
alert(k ** l);


