let numero = Number(prompt("Digite um número para calcular o cubo:"));
function calculaCubo(num) {
    return num * num * num;
}
alert(calculaCubo(numero));